package com.cg.mba.exception;

public class MbaException extends Exception{

	public MbaException(String message){
		super(message);

	}
}
