package CustomerAccount;


import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


import com.demo.Address;
import com.demo.Customer;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {

	private Customer cust;
	private double openbal;
	
	
	
	@Given("^Customer and opening balance$")
	public void customer_and_opening_balance() throws Throwable {
	 Address add = new Address("Hinjewadi","Pune");
	 cust = new Customer("Akshay","Bansod",add);
	 openbal=5000;
	   
	}

	@When("^for a valid customer$")
	public void for_a_valid_customer() throws Throwable {
	    assertNotNull(cust);
	    
	}

	@When("^valid opening balance create account number$")
	public void valid_opening_balance_create_account_number() throws Throwable {
	    assertTrue(openbal>500);
	    
	}

	@Then("^Create account and store it into DB$")
	public void create_account_and_store_it_into_DB() throws Throwable {
	    
		
	}









}
