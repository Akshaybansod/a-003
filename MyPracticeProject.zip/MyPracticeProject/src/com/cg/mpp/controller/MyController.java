package com.cg.mpp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mpp.dto.Products;
import com.cg.mpp.service.IProductService;

@Controller
public class MyController {
	
	
	@Autowired
	IProductService service;
	
	public IProductService getService()
	{
		return service;
	}

	public void setService(IProductService service)
	{
		this.service=service;
	}
	
	
	@RequestMapping("getprodlist")
	public String showProdList(Model model)
	{
		List<Products> list = service.getAllProducts();
		model.addAttribute("list",list);
		return "home";
		
	}
	
	@RequestMapping("getUpdatePage")
	public String sendUpdatepage(@RequestParam("prodid") int prodid,Model model)
	{
		Products product=service.getProductsDetails(prodid);
		if(product==null){
			model.addAttribute("errmsg","Product Id is invalid..."+prodid);
			return "index";
		}
		else{
			model.addAttribute("product", product);
			return "Update";
		}
	}
	
	@RequestMapping("updateProductApplication")
	public ModelAndView updateProduct(@ModelAttribute("product") Products product)
	{	
		service.updateProduct(product);
		return new ModelAndView("updateSuccess","temp",product);
	}


	@RequestMapping("delete")
	public String deleteMobile(@RequestParam("prodid") int id)
	{	
		service.deleteProducts(id);;
		return "deleteSuccess";
	}
	
	@RequestMapping("insert")
	public String insertProduct(@ModelAttribute("product") Products product){		
		
		return "Insert";
		
	}
	
	@RequestMapping("inserted")
	public String insertedData(@ModelAttribute("product") Products product, BindingResult result){
		
		
		if(result.hasErrors())
		{
			return "insertFailure";
		}
		else
		{
			service.insertProduct(product);
			return "insertSuccess";
		}
		
	}
	
	
}
