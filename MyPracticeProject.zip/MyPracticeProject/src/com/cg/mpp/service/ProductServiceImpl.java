package com.cg.mpp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mpp.dao.IProductDao;
import com.cg.mpp.dto.Products;

@Service
public class ProductServiceImpl implements IProductService{

	
	
	@Autowired
	IProductDao dao;
	
	
	
	
	@Override
	public List<Products> getAllProducts() {
		
		return dao.getAllProducts();
	}

	@Override
	public Products getProductsDetails(int prodid) {
		
		return dao.getProductsDetails(prodid);
	}

	@Override
	public void updateProduct(Products product) {
		dao.updateProduct(product);
		
	}

	@Override
	public void deleteProducts(int id) {
		dao.deleteProducts(id);
		
	}

	@Override
	public void insertProduct(Products product) {
		dao.insertProduct(product);
	}

}
