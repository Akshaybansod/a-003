package com.cg.mpp.service;

import java.util.List;

import com.cg.mpp.dto.Products;


public interface IProductService {
	
	
	public List<Products> getAllProducts();
	public Products getProductsDetails(int prodid);
	public void insertProduct(Products product);
	public void updateProduct(Products product);
	public void deleteProducts(int id);
	
	
	
	
	

}
