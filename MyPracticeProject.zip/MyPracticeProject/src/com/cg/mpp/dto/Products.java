package com.cg.mpp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Products {

	@Id
	@Column(name="prod_id")
	private int prodId;
	
	@Column
	private String name;
	
	@Column
	private double price;
	
	@Column
	private int quantity;

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Products [prodId=" + prodId + ", name=" + name + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
