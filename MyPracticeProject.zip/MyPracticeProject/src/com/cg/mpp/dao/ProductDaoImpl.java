package com.cg.mpp.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.cg.mpp.dto.Products;

@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {

	
	@PersistenceContext
	EntityManager em;
	
	public EntityManager getManager()
	{
		return em;
	}
	public void setManager(EntityManager manager)
	{
		this.em=manager;
	}	
	
	
	
	
	
	@Override
	public List<Products> getAllProducts() {
		String str = "select product from Products product";
		TypedQuery<Products> query= em.createQuery(str,Products.class);
		return query.getResultList();
	}

	@Override
	public Products getProductsDetails(int prodid) {
		Products product = em.find(Products.class,prodid);
		return product;
	}

	@Override
	public void updateProduct(Products product) {
		em.merge(product);
		em.flush();

	}

	@Override
	public void deleteProducts(int id) {
		Products product=getProductsDetails(id);
		em.remove(product);
		em.flush();

	}
	
	@Override
	public void insertProduct(Products product) {
		em.persist(product);
		em.flush();
	}

}
