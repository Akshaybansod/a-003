package com.cg.mobshop.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mobshop.dto.Mobiles;

@Repository
@Transactional
public class MobileDaoImpl implements MobileDao {

	@PersistenceContext
	EntityManager em;
	
	public EntityManager getManager()
	{
		return em;
	}
	public void setManager(EntityManager manager)
	{
		this.em=manager;
	}	
	
	@Override
	public List<Mobiles> getAllMobiles() {
		System.out.println("in DAO class");
		String str = "select mobile from Mobiles mobile";
		TypedQuery<Mobiles> query= em.createQuery(str,Mobiles.class);
		return query.getResultList();
		
	}
	@Override
	public Mobiles getMobileDetails(int mobid) {
		Mobiles mobile = em.find(Mobiles.class,mobid);
		return mobile;
	}
	@Override
	public void updateMobile(Mobiles mob) {
		em.merge(mob);
		em.flush();
	}
	@Override
	public void deleteMobile(int id) {
		Mobiles mobile=getMobileDetails(id);
		em.remove(mobile);
		em.flush();
	}
	

}
