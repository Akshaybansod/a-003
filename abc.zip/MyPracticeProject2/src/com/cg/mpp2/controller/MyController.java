package com.cg.mpp2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mpp2.dto.Bikes;
import com.cg.mpp2.service.IBikes;


@Controller
public class MyController {
	
	@Autowired
	IBikes service;
	
	public IBikes getService()
	{
		return service;
	}

	public void setService(IBikes service)
	{
		this.service=service;
	}
	
	@RequestMapping("getbikelist")
	public String showBikeList(Model model)
	{
		List<Bikes> list = service.getAllBikes();
		model.addAttribute("list",list);
		return "Home";
	}
	
	public String sendUpdatepage(@RequestParam("mobid") int mobid,Model model)
	{
		Bikes bike=service.getBikeDetails(mobid);
		if(bike==null){
			model.addAttribute("errmsg","Bike varient is invalid..."+mobid);
			return "index";
		}
		else{
			model.addAttribute("mobile", bike);
			return "Update";
		}
	}

	
	
	public ModelAndView updateBike(@ModelAttribute("mobile") Bikes bike)
	{	
		service.updateBike(bike);;

		return new ModelAndView("updateSuccess","temp",bike);
	}
	
	public String deleteBike(@RequestParam("mobid") int id)
	{	
		service.removeBike(id);;
		return "deleteSuccess";
	}

}
