package com.cg.mpp2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mpp2.dao.IBikesDao;
import com.cg.mpp2.dto.Bikes;

@Service
public class BikesImpl implements IBikes {

	@Autowired
	IBikesDao dao;
	
	
	@Override
	public List<Bikes> getAllBikes() {
		
		return dao.getAllBikes();
	}

	@Override
	public Bikes getBikeDetails(int varient) {
		// TODO Auto-generated method stub
		return dao.getBikeDetails(varient);
	}

	@Override
	public void updateBike(Bikes bike) {
		dao.updateBike(bike);
		
	}

	@Override
	public void removeBike(int varient) {
		dao.removeBike(varient);
		
	}

}
