package com.cg.mpp2.service;

import java.util.List;

import com.cg.mpp2.dto.Bikes;

public interface IBikes {
	
	
	public List<Bikes> getAllBikes();
	public Bikes getBikeDetails(int varient);
	public void updateBike(Bikes bike);
	public void removeBike(int varient);
	

}
