package com.cg.mpp2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mpp2.dto.Bikes;

@Repository
@Transactional
public class BikesDaoImpl implements IBikesDao {

	@PersistenceContext
	EntityManager em;
	
	public EntityManager getManager()
	{
		return em;
	}
	public void setManager(EntityManager manager)
	{
		this.em=manager;
	}	
	
	@Override
	public List<Bikes> getAllBikes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bikes getBikeDetails(int varient) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateBike(Bikes bike) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeBike(int varient) {
		// TODO Auto-generated method stub
		
	}

}
