package com.cg.mpp2.dto;

import javax.persistence.*;


@Entity
@Table
public class Bikes {
	
	@Column
	private String model;
	
	@Column
	@Id
	private int varient;
	
	
	@Column
	private double cc;
	
	@Column
	private double price;
	
	
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	public double getCc() {
		return cc;
	}
	public void setCc(double cc) {
		this.cc = cc;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getVarient() {
		return varient;
	}
	public void setVarient(int varient) {
		this.varient = varient;
	}
	@Override
	public String toString() {
		return "Bikes [model=" + model + ", varient=" + varient + ", cc=" + cc
				+ ", price=" + price + "]";
	}
	
	
	

}
